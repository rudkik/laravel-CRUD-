<?php $__env->startSection('content'); ?>
<?php

?>
<a>
    здрасте
</a>

    <?php $__env->stopSection(); ?>


<?php /**PATH /Applications/MAMP/htdocs/laravel/resources/views/layouts/layouts.blade.php ENDPATH**/ ?>