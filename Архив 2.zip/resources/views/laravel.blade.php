@extends('layouts.layouts') <?php //включает файл можно сразу файли или сначала деркторию точка последующая вложенность?>

@yield('content')   <?php // указывает на включаемую секцию можно прописать @section @endsection  и вызвать через эту функцию ?>


@foreach($array as $ar )

    <ul>{{ $ar }}</ul>
@endforeach
