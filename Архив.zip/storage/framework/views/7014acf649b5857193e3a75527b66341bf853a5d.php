 <?php //включает файл можно сразу файли или сначала деркторию точка последующая вложенность?>

<?php echo $__env->yieldContent('content'); ?>   <?php // указывает на включаемую секцию можно прописать @section @endsection  и вызвать через эту функцию ?>


<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <ul><?php echo e($ar); ?></ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel/resources/views/laravel.blade.php ENDPATH**/ ?>