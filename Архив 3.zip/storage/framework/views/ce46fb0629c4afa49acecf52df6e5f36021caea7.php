 <?php //включает файл можно сразу файли или сначала деркторию точка последующая вложенность?>



<?php $__env->startSection('content'); ?>
    <h1>Pages Todo</h1>
    <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="list-group">
            <li class="list-group-item d-flex justify-content-between align-items-center">
               <?php echo e($todo->title); ?>

                <?php if($todo->status === 1): ?>
                <span class="badge bg-success rounded-pill">Выполнено</span>
                <?php else: ?>
                <span class="badge bg-danger rounded-pill">Выполнено</span>
                <?php endif; ?>
            </li>
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel/resources/views/todos.blade.php ENDPATH**/ ?>